1. Title : 
	Multiple Tab width adjustment in one line using CSS

2. Asset Owner and mail ID : 
	Deepika Ray - deepika.ray@tcs.com
	Component Engineering Group - CEG-CIG-System

    
2. Asset Author and mail ID : 
	Deepika Ray - deepika.ray@tcs.com
	Component Engineering Group - CEG-CIG-System

3. Configuration instructions
	3.1. List of configuration files in directory and their purpose

	    - jquery.min.js - Main framework file.

		- script.js - This js invokes respective methods from used plugins.
	.
4. Installation instructions
	- Download and Extract zip file

	- Copy all CSS/JS files in your CSS/JS folder

	- Copy the HTML code from the HTML file into your webpage,where you need this component to be rendered 
		
5. Operating instructions
	- Open the HTML page in browser

6. File Lists
	- CSS
		- reset.css, default.css, custom.css, style.css
	- js
		- jquery
			- jquery.min.js

		- script.js

7. Copyright and licensing information
	Proprietary License Terms and Condition as enforced by Tata Consultancy Services Limited. 

8. Known Constraints
	NA

9. A change-log
	Version 1.0 dated 27 February 2016

10. References
	http://api.jquery.com/