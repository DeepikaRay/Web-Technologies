$(document).ready(function() {
    $("#myTab .myTabs").click(function() {
        if (!$(this).hasClass("active")) {
            $("#myTab .myTabs").removeClass("active");
            $(".tab-content").removeClass("active");
            $(this).addClass("active");
            var elementID = $(this).children("a").attr("href");
            $(elementID).addClass("active");
        }

    });

    $("#simpleTabs .tabs").click(function() {
        if (!$(this).hasClass("active")) {
            $("#simpleTabs .tabs").removeClass("active");
            $(".dvDetails").removeClass("active");
            $(this).addClass("active");
            var elementID = $(this).children("a").attr("href");
            $(elementID).addClass("active");
        }

    });

});